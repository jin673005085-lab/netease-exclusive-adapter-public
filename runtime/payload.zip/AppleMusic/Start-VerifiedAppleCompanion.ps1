﻿[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$nativeModules=Join-Path $PSHOME 'Modules'
$windowsModules=Join-Path $env:ProgramFiles 'WindowsPowerShell\Modules'
$env:PSModulePath=(@($nativeModules,$windowsModules)+@($env:PSModulePath -split ';')|Select-Object -Unique)-join ';'
$expected=[IO.Path]::GetFullPath((Join-Path $env:PUBLIC 'AMExclusive'))
if([IO.Path]::GetFullPath($PSScriptRoot) -ne $expected){throw 'Unexpected companion directory'}
$log=Join-Path $PSScriptRoot 'verified-startup.log'
try{
    $package=Get-AppxPackage -Name AppleInc.AppleMusicWin -ErrorAction SilentlyContinue|Sort-Object Version -Descending|Select-Object -First 1
    if(-not $package){return}
    $fingerprints=@{
        'AppleMusic.exe'='50D9F6393A8578B7DDFB6F7E550BB8D2B2A10C32E55AC159D3463A3ECA775227'
        'AMPLibraryAgent.exe'='4AD22991186710051E872FDCDBAB91980A55802BE75F931044399A38D0CB5C30'
        'CoreMedia.dll'='505AD3A5A804C1A00A2F58A8237292F000EFACB0EE57850E5B6B3716ADF155CE'
    }
    foreach($name in $fingerprints.Keys){
        $file=Join-Path $package.InstallLocation $name
        if(-not(Test-Path -LiteralPath $file) -or (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $fingerprints[$name]){
            $versions=@('软件包版本 '+[string]$package.Version)
            foreach($clientFile in @('AppleMusic.exe','AMPLibraryAgent.exe')){
                $clientPath=Join-Path $package.InstallLocation $clientFile
                $version='未能读取'
                try{
                    if(Test-Path -LiteralPath $clientPath -PathType Leaf){
                        $value=[Diagnostics.FileVersionInfo]::GetVersionInfo($clientPath).FileVersion
                        if($value){$version=$value.Trim()}
                    }else{$version='文件不存在'}
                }catch{$version='读取失败：'+$_.Exception.Message}
                $versions+=($clientFile+' 文件版本 '+$version)
            }
            $reason='Apple Music：当前版本不支持。已支持版本：软件包 1.1540.23042.0 x64（AppleMusic.exe / AMPLibraryAgent.exe 文件版本 1.6.4.90）。当前探测到的版本：'+($versions -join '；')+'。原因：'+$name+' 文件缺失或 SHA256 与已验证构建不匹配；版本号相同也必须通过文件指纹校验。已跳过注入。路径：'+$package.InstallLocation
            Add-Content -LiteralPath $log -Encoding utf8 -Value ((Get-Date -Format o)+' '+$reason)
            return
        }
    }
    $payload=@{
        'am-exclusive-broker.exe'='8E0E04D241EF6F754B16595782B40F4A544FA850D5721667E8774D3D2638AC05'
        'am-exclusive-hook.dll'='BED0C30B30AF0AB89B21043A64454F70C198776629E749B59BEA5DC2718AA6B4'
        'am-exclusive-ui.dll'='0DD94B085CBC081628169E6A083BC1EAAA7A79E3F2286A1267E12F7B6365E3D7'
    }
    foreach($name in $payload.Keys){
        $file=Join-Path $PSScriptRoot $name
        if(-not(Test-Path -LiteralPath $file) -or (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $payload[$name]){throw ('Companion payload changed: '+$name)}
    }
    $hostPath=Join-Path $package.InstallLocation 'AppleMusic.exe'
    if(-not @(Get-CimInstance Win32_Process -Filter "Name='AppleMusic.exe'"|Where-Object ExecutablePath -EQ $hostPath).Count){return}
    Add-Content -LiteralPath $log -Encoding utf8 -Value ((Get-Date -Format o)+' fingerprints verified; starting PID-bound companion')
    $companion=Start-Process -FilePath (Join-Path $PSScriptRoot 'am-exclusive-broker.exe') -WindowStyle Hidden -PassThru
    $companion.WaitForExit()
}catch{Add-Content -LiteralPath $log -Encoding utf8 -Value ((Get-Date -Format o)+' startup refused: '+$_.Exception.Message);exit 1}
